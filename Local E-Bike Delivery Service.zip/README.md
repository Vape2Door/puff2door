
  # Local E-Bike Delivery Service

  This is a code bundle for Local E-Bike Delivery Service. The original project is available at https://www.figma.com/design/OKf07UIrPji2rD2W47nMEU/Local-E-Bike-Delivery-Service.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  