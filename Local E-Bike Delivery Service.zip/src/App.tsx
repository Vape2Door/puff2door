import { Bike, Package, MessageSquare, CheckCircle, Mail, Instagram } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 mb-6">
            <Bike className="w-10 h-10 text-emerald-600" />
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900">Puff2Door</h1>
          </div>
          <p className="text-xl md:text-2xl text-slate-700 mb-4">
            Local E‑Bike Delivery for Dunedin Vape Shops
          </p>
        </div>
      </header>

      {/* What We Do Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <h2 className="text-3xl font-semibold text-slate-900 mb-4 text-center">What we do</h2>
          <p className="text-lg text-slate-700 text-center">
            Same‑day, discreet local delivery for your customers.
          </p>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-semibold text-slate-900 mb-12 text-center">How it works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-emerald-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-emerald-700" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Customer orders from your store</h3>
            </div>
            <div className="text-center">
              <div className="bg-emerald-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <MessageSquare className="w-8 h-8 text-emerald-700" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">You message Puff2Door</h3>
            </div>
            <div className="text-center">
              <div className="bg-emerald-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Bike className="w-8 h-8 text-emerald-700" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">We collect & deliver</h3>
            </div>
          </div>
          <p className="text-center text-slate-700 mt-12 text-lg">
            No apps. No contracts. No drivers to manage.
          </p>
        </div>
      </section>

      {/* Why Use Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto bg-emerald-50 rounded-2xl shadow-lg p-8 md:p-12">
          <h2 className="text-3xl font-semibold text-slate-900 mb-8 text-center">Why use Puff2Door</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-1" />
              <span className="text-lg text-slate-800">Faster local delivery</span>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-1" />
              <span className="text-lg text-slate-800">Lower cost than car couriers</span>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-1" />
              <span className="text-lg text-slate-800">No staff or vehicle overheads</span>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-1" />
              <span className="text-lg text-slate-800">Eco‑friendly e‑bike service</span>
            </div>
          </div>
        </div>
      </section>

      {/* Get Started Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-semibold text-slate-900 mb-8">Get started</h2>
          <div className="space-y-4">
            <a 
              href="mailto:thygoodisreborn@gmail.com"
              className="inline-flex items-center gap-3 text-lg text-slate-700 hover:text-emerald-600 transition-colors"
            >
              <Mail className="w-6 h-6" />
              <span>thygoodisreborn@gmail.com</span>
            </a>
            <br />
            <a 
              href="https://instagram.com/Puff2Door"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 text-lg text-slate-700 hover:text-emerald-600 transition-colors"
            >
              <Instagram className="w-6 h-6" />
              <span>@Puff2Door</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-8 border-t border-slate-200">
        <p className="text-sm text-slate-600 text-center max-w-3xl mx-auto">
          Independent delivery service. Retailers remain responsible for age‑restricted sales and compliance.
        </p>
      </footer>
    </div>
  );
}